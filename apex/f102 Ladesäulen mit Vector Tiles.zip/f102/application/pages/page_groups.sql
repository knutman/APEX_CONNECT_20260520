prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3744381428704641
,p_default_application_id=>101
,p_default_id_offset=>3782176269594792
,p_default_owner=>'CHASTA'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3757987053758014)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
