prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3744381428704641
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'CHASTA'
);
null;
wwv_flow_imp.component_end;
end;
/
