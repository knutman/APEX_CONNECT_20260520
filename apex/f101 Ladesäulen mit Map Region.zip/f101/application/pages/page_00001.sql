prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3744381428704641
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'CHASTA'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>unistr('Lades\00E4ulen mit Map Region')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3765551961758054)
,p_plug_name=>unistr('Lades\00E4ulen mit Map Region')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3768262748769101)
,p_plug_name=>'Karte'
,p_title=>unistr('Lades\00E4ulen mit Map Region')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(3768364567769102)
,p_region_id=>wwv_flow_imp.id(3768262748769101)
,p_height=>800
,p_tilelayer_type=>'CUSTOM'
,p_tilelayer_name_default=>'osm-positron'
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_from_browser=>false
,p_init_position_lon_static=>'11.0767'
,p_init_position_lat_static=>'49.4521'
,p_init_zoomlevel_static=>'12'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM:RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP:BROWSER_LOCATION'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(3768467241769103)
,p_map_region_id=>wwv_flow_imp.id(3768364567769102)
,p_name=>unistr('Lades\00E4ulen')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ccs.cha_charging_station_id,',
'        ccs.geo,',
'        ccs.cha_charging_station_ext_id,',
'        coalesce(ccs.operator_displayname, ccs.operator_companyname,',
'                 ''Unbekannter Betreiber'')                              as operator_name,',
'        case when ccs.operator_displayname is not null',
'              and ccs.operator_companyname is not null',
'              and upper(ccs.operator_displayname) <> upper(ccs.operator_companyname)',
'             then ccs.operator_companyname',
'        end                                                            as operator_secondary,',
'        ccs.status_operational,',
'        case ccs.status_operational',
'          when ''In Betrieb'' then ''cha-popup__badge--ok''',
'          when ''In Wartung'' then ''cha-popup__badge--warn''',
'          else                   ''cha-popup__badge--unknown''',
'        end                                                            as status_class,',
'        case ccs.station_type',
'          when ''Schnellladeeinrichtung'' then ''#dc2626''',
'          when ''Normalladeeinrichtung''  then ''#2563eb''',
'        end as pin_color,',
'        ccs.station_type,',
'        ccs.location_description,',
'        trim(ccs.street || '' '' || ccs.house_no)                        as street_line,',
'        ccs.address_addition,',
'        trim(ccs.postal_code || '' '' || ccs.city)                       as city_line,',
'        nullif(trim(ccs.district_independent_city || '', '' || ccs.state),',
'               '', '')                                                   as region_line,',
'        ccs.latitude, ccs.longitude,',
unistr('        nvl(ccs.access_restriction, ''\2014'')                               as access_restriction,'),
unistr('        nvl(to_char(ccs.go_live_date, ''DD.MM.YYYY''), ''\2014'')              as go_live_date_fmt,'),
unistr('        nvl(ccs.opening_hours_specification, ''\2014'')                      as opening_hours_specification,'),
'        nvl(to_char(ccs.max_electric_power_station_in_kw,',
'                    ''FM999G990D0'', ''NLS_NUMERIC_CHARACTERS=,.''),',
unistr('            ''\2014'') || '' kW''                                              as power_fmt,'),
unistr('        nvl(( select listagg(ps.value, '' \00B7 '') within group (order by ps.value)'),
'                from json_table(ccs.payment_systems, ''$[*]''',
'                       columns (value varchar2(100) path ''$'')) ps',
unistr('            ), ''\2014'')                                                    as payment_systems_fmt,'),
unistr('        nvl(( select listagg(od.day || '' '' || od.hours, '' \00B7 '')'),
'                       within group (order by od.day)',
'                from json_table(ccs.opening_days, ''$[*]''',
'                       columns (day   varchar2(20) path ''$.day'',',
'                                hours varchar2(40) path ''$.hours'')) od',
unistr('            ), ''\2014'')                                                    as opening_days_fmt,'),
unistr('        -- Platzhalter \2014 sobald wir die echte JSON-Struktur kennen, anpassen'),
unistr('        nvl(( select listagg(g.label, '' \00B7 '') within group (order by g.label)'),
unistr('        from ( select case when count(*) > 1 then count(*) || ''\00D7 '' end'),
'                        || c.connector_type',
'                        || '' / ''',
'                        || to_char(c.power, ''FM999G990D0'',',
'                                   ''NLS_NUMERIC_CHARACTERS=,.'')',
'                        || '' kW''                                       as label',
'                 from json_table(ccs.evse, ''$[*]''',
'                        columns (',
'                          nested path ''$.connectors[*]'' columns (',
'                            connector_type varchar2(60) path ''$.connector_type'',',
'                            power          number       path ''$.max_electric_power_connector''',
'                          )',
'                        )) c',
'                where c.connector_type is not null',
'                group by c.connector_type, c.power',
'             ) g',
unistr('    ), ''\2014'')                                                            as evse_fmt,'),
'        to_char(coalesce(ccs.updated_dt, ccs.created_dt),',
'                ''DD.MM.YYYY HH24:MI'')                                  as stand_fmt',
'  from  cha_charging_station ccs'))
,p_has_spatial_index=>true
,p_pk_column=>'CHA_CHARGING_STATION_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEO'
,p_fill_color=>'&PIN_COLOR.'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Pin Circle'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
unistr('  /* MapLibre-Popup-Container vergr\00F6\00DFern + scrollbar machen */'),
'  .maplibregl-popup-content {',
'    max-width: 460px !important;',
'    max-height: 70vh;',
'    overflow-y: auto;',
'    padding: 14px 18px !important;',
'    border-radius: 8px;',
'  }',
'  .maplibregl-popup-close-button { font-size: 18px; padding: 2px 8px; }',
'',
'  .cha-popup { font: 13px/1.45 system-ui, sans-serif; color: #1f2937; }',
'  .cha-popup__head { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; margin-bottom: 8px; }',
'  .cha-popup__name { margin: 0; font-size: 15px; line-height: 1.25; }',
'  .cha-popup__subname { font-size: 11px; color: #6b7280; margin-top: 2px; }',
'  .cha-popup__subname:empty { display: none; }',
'  .cha-popup__badge { flex: none; font-size: 11px; padding: 2px 8px; border-radius: 999px; white-space: nowrap; }',
'  .cha-popup__badge--ok      { background: #d1fae5; color: #065f46; }',
'  .cha-popup__badge--warn    { background: #fef3c7; color: #92400e; }',
'  .cha-popup__badge--unknown { background: #e5e7eb; color: #374151; }',
'  .cha-popup__addr { font-style: normal; margin: 0 0 6px; color: #374151; }',
'  .cha-popup__addr-add:empty { display: none; }',
'  .cha-popup__addr-add:not(:empty)::after { content: "\A"; white-space: pre; }',
'  .cha-popup__region:empty { display: none; }',
'  .cha-popup__loc { margin: 0 0 10px; font-style: italic; color: #6b7280; }',
'  .cha-popup__loc:empty { display: none; }',
'  .cha-popup__grid { display: grid; grid-template-columns: max-content 1fr; gap: 3px 14px; margin: 0; }',
'  .cha-popup__grid dt { color: #6b7280; font-weight: 500; }',
'  .cha-popup__grid dd { margin: 0; }',
'  .cha-popup__foot { margin-top: 10px; font-size: 11px; color: #9ca3af; text-align: right; border-top: 1px solid #f3f4f6; padding-top: 6px; }',
'</style>',
'',
'<div class="cha-popup">',
'  <header class="cha-popup__head">',
'    <div>',
'      <h3 class="cha-popup__name">&OPERATOR_NAME.</h3>',
'      <div class="cha-popup__subname">&OPERATOR_SECONDARY.</div>',
'    </div>',
'    <span class="cha-popup__badge &STATUS_CLASS.">&STATUS_OPERATIONAL.</span>',
'  </header>',
'',
'  <address class="cha-popup__addr">',
'    &STREET_LINE.<br>',
'    <span class="cha-popup__addr-add">&ADDRESS_ADDITION.</span>',
'    &CITY_LINE.<br>',
'    <span class="cha-popup__region">&REGION_LINE.</span>',
'  </address>',
'',
'  <p class="cha-popup__loc">&LOCATION_DESCRIPTION.</p>',
'',
'  <dl class="cha-popup__grid">',
'    <dt>BNetzA-ID</dt>      <dd>&CHA_CHARGING_STATION_EXT_ID.</dd>',
'    <dt>Art</dt>            <dd>&STATION_TYPE.</dd>',
'    <dt>Nennleistung</dt>   <dd>&POWER_FMT.</dd>',
'    <dt>Inbetriebnahme</dt> <dd>&GO_LIVE_DATE_FMT.</dd>',
unistr('    <dt>\00D6ffnungszeiten</dt> <dd>&OPENING_HOURS_SPECIFICATION.</dd>'),
'    <dt>Zugang</dt>         <dd>&ACCESS_RESTRICTION.</dd>',
'    <dt>Bezahlung</dt>      <dd>&PAYMENT_SYSTEMS_FMT.</dd>',
'    <dt>Ladepunkte</dt>     <dd>&EVSE_FMT.</dd>',
'    <dt>Koordinaten</dt>    <dd>&LATITUDE., &LONGITUDE.</dd>',
'  </dl>',
'',
'  <footer class="cha-popup__foot">Stand: &STAND_FMT.</footer>',
'</div>'))
,p_allow_hide=>true
);
wwv_flow_imp.component_end;
end;
/
